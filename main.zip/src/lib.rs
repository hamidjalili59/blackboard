pub mod proto {
    include!(concat!(env!("OUT_DIR"), "/communication.rs"));
}